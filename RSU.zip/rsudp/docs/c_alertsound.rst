:py:data:`rsudp.c_alertsound` (play sound)
=====================================================

.. automodule:: rsudp.c_alertsound
    :members:

................

* :ref:`genindex`
* :ref:`search`
.. * :ref:`modindex`

`Back to top ↑ <#top>`_
